<?php
$pageTitle = "Welcome to Flashcard Learning Platform";
require_once 'includes/header.php';
?>
<h2>Home</h2>
<p>Welcome to our learning platform! Explore flashcards, quizzes, and study guides to enhance your knowledge.</p>
<?php require_once 'includes/footer.php'; ?>
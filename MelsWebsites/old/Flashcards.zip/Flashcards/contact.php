<?php
$pageTitle = "Contact Us";
require_once 'includes/header.php';
?>
<h2>Contact</h2>
<p>Email us at: <a href="mailto:support@example.com">support@example.com</a></p>
<?php require_once 'includes/footer.php'; ?>
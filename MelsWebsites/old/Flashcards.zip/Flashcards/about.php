<?php
$pageTitle = "About Us";
require_once 'includes/header.php';
?>
<h2>About</h2>
<p>We are dedicated to providing free, accessible learning tools for students and professionals alike.</p>
<?php require_once 'includes/footer.php'; ?>
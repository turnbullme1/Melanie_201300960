    </main>
    <footer>
        <p>© <?php echo date('Y'); ?> Flashcard Learning Platform. All rights reserved.</p>
    </footer>
</body>
</html>